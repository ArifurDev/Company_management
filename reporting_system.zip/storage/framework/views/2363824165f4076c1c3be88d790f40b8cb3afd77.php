<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-lg-12 grid-margin stretch-card">
                            <div class="card">
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                              <div class="card-body">


                                <h4 class="card-title">Admin Daily Report Search Result.........</h4>


                                 <!-- Large Modal -->

                                <div class="table-responsive">
                                  <table class="table table-dark">
                                    <thead>
                                      <tr>
                                        <th> House Rent </th>
                                        <th> Gard Bill </th>
                                        <th> Electricity Bill </th>
                                        <th> Sewerage Bill </th>
                                        <th> Expanse </th>
                                        <th> Personal </th>
                                        <th> Loan </th>
                                        <th> Total </th>
                                        <th> Date </th>
                                        <th> Action </th>
                                      </tr>
                                    </thead>
                                    <?php
                                        $total_outgoing = 0;
                                    ?>
                                    <tbody class="alldata">
                                        <?php $__currentLoopData = $search_result_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($result_data->house_rent); ?> tk</td>
                                            <td> <?php echo e($result_data->gard_bill); ?> tk</td>
                                            <td> <?php echo e($result_data->electricity_bill); ?> tk</td>
                                            <td> <?php echo e($result_data->sewerage_bill); ?> tk</td>
                                            <td> <?php echo e($result_data->expanse); ?> tk</td>
                                            <td> <?php echo e($result_data->personal); ?> tk</td>
                                            <td> <?php echo e($result_data->loan); ?> tk</td>
                                            <td> <?php echo e($result_data->total); ?> tk</td>
                                            <td> <?php echo e($result_data->created_at->format('d/m/Y')); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">

                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.edit',['id'=>$result_data->id])); ?>" title="edit">
                                                        <i class="mdi mdi-border-color"></i>
                                                    </a>
                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.destroy',['id'=>$result_data->id])); ?>" title="delete tem">
                                                        <i class="mdi mdi-delete"></i>
                                                    </a>
                                            </div></td>
                                            <?php
                                                $total_outgoing = $total_outgoing + $result_data->total;
                                            ?>
                                          </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>T.Cost=<?php echo e($total_outgoing); ?> tk</td>
                                            <td></td>
                                            <td></td>
                                          </tr>
                                    </tbody>

                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                    </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/admin/report/search_result_data.blade.php ENDPATH**/ ?>