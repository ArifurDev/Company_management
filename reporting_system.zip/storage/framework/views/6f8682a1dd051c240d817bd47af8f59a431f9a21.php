<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-lg-12 grid-margin stretch-card">
                            <div class="card">
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-primary" role="alert">
                                    <?php echo e(session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                              <div class="card-body">
                                <h4 class="card-title">Empolyees Reports</h4>
                     
                                <div class="d-flex justify-content-end align-items-center">



                                    
                                    <button type="button" class="btn btn-danger m-2" data-bs-toggle="modal" data-bs-target="#largeModal">
                                       Trash Bin
                                     </button>
                                </div>
                                  <!-- Large Modal -->
                                <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content  bg-dark">
                                        <div class="modal-header ">
                                        <h5 class="modal-title" id="exampleModalLabel3">Trash Bin</h5>
                                        <button type="button"class="btn-close"data-bs-dismiss="modal"aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-1">
                                            <div class="table-responsive text-nowrap">
                                                <table class="table table-dark">

                                                <thead>
                                                    <tr>

                                                        <th> Site Name </th>
                                                        <th> URL </th>
                                                        <th> U.N </th>
                                                        <th> U.I </th>
                                                        <th> Password </th>
                                                        <th> Verifi Code </th>
                                                        <th> Payment Date </th>
                                                        <th> Save Date </th>
                                                        <th> Acction </th>
                                                    </tr>
                                                </thead>

                                                    <?php $__currentLoopData = $reportinfo_treshed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treshed_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td> <?php echo e($treshed_info->site_name); ?> </td>
                                                        <td> <?php echo e($treshed_info->url); ?> </td>
                                                        <td> <?php echo e($treshed_info->user_name); ?> </td>
                                                        <td> <?php echo e($treshed_info->user_id); ?> </td>
                                                        <td> <?php echo e($treshed_info->password); ?> </td>
                                                        <td> <?php echo e($treshed_info->verifi_code); ?> </td>
                                                        <td> <?php echo e($treshed_info->payment_date); ?> </td>
                                                        <td> <?php echo e($treshed_info->created_at->format('d/m/Y')); ?></td>
                                                        <td>
                                                            <div class="btn-group" role="group" aria-label="Basic example">

                                                                <a type="button" class="btn btn-primary" href="<?php echo e(route('restor.adminwebreport',['id'=>$treshed_info->id])); ?>" title="restore">
                                                                    <i class="mdi mdi-backup-restore"></i>
                                                                </a>
                                                                <a type="button" class="btn btn-primary" href="<?php echo e(route('delete.adminwebreport',['id'=>$treshed_info->id])); ?>" title="delete forever">
                                                                    <i class="mdi mdi-delete-forever"></i>
                                                                </a>
                                                        </div></td>

                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>

                                        </div>

                                    </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                  <table class="table table-dark">
                                    <thead>
                                      <tr>

                                        <th> Site Name </th>
                                        <th> URL </th>
                                        <th> U.N </th>
                                        <th> U.I </th>
                                        <th> Password </th>
                                        <th> Verifi Code </th>
                                        <th> Payment Date </th>
                                        <th> Save Date </th>
                                        <th> Acction </th>
                                      </tr>
                                    </thead>

                                    <tbody class="alldata">

                                        <?php $__currentLoopData = $reportinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($info->site_name); ?> </td>
                                            <td> <?php echo e($info->url); ?> </td>
                                            <td> <?php echo e($info->user_name); ?> </td>
                                            <td> <?php echo e($info->user_id); ?> </td>
                                            <td> <?php echo e($info->password); ?> </td>
                                            <td> <?php echo e($info->verifi_code); ?> </td>
                                            <td> <?php echo e($info->payment_date); ?> </td>
                                            <td> <?php echo e($info->created_at->format('d/m/Y')); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">

                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('adminwebreport.edit',['id'=>$info->id])); ?>" title="edit">
                                                        <i class="mdi mdi-border-color"></i>
                                                    </a>
                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('adminwebreport.destroy',['id'=>$info->id])); ?>" title="delete tem">
                                                        <i class="mdi mdi-delete"></i>
                                                    </a>
                                            </div></td>

                                          </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                  </table>
                                  <div class="d-flex justify-content-center mt-3">

                                    <?php echo e($reportinfo->links('pagination::bootstrap-5')); ?>

                                </div>
                                </div>
                              </div>
                            </div>
                          </div>
                    </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <script type="text/javascript">

        $('#search').on('keyup',function()
        {

         $value=$(this).val();

         if($value)
         {
             $('.alldata').hide();
             $('.searchdata').show();
         }else
         {
             $('.alldata').show();
             $('.searchdata').hide();
         }

         $.ajax({
                 type:'get',
                 url:'<?php echo e(URL::to('empolyeereportsearch')); ?>',
                 data:{'search':$value},
                 success:function(data)
                 {
                     console.log(data);
                     $('#Content').html(data);
                 }
             });

         });
     </script>
</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/admin/adminwebreportshow.blade.php ENDPATH**/ ?>