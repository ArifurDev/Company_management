<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Empolyees</h4>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="d-flex justify-content-between align-items-center">
                                    

                                    
                                    <button type="button" class="btn btn-danger mb-2" data-bs-toggle="modal"
                                        data-bs-target="#largeModal">
                                        <i class="mdi mdi-account d-block mb-1"> Add</i>
                                    </button>


                                        <div class="col-md-4">
                                            <div class="form-group row">


                                        <div class="col-sm-9">
                                                    <input type="search" class="form-control" name="search" id="search" placeholder="search here......">
                                                </div>
                                            </div>
                                        </div>

                                </div>
                                

                                
                                <!-- Large Modal -->
                                <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content  bg-dark">
                                            <div class="modal-header ">
                                                <h5 class="modal-title" id="exampleModalLabel3">Create a New Empolyees
                                                </h5>
                                                <button
                                                    type="button"class="btn-close"data-bs-dismiss="modal"aria-label="Close"></button>


                                            </div>
                                            <div class="modal-body m-1">
                                                <div class="table-responsive text-nowrap">
                                                    <div class="col-12 grid-margin">
                                                        <div class="card">
                                                            <?php if($errors->any()): ?>
                                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <ul>
                                                                        <li>
                                                                            <p class="text-light"><?php echo e($error); ?>

                                                                            </p>
                                                                        </li>
                                                                    </ul>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                            <div class="card-body">

                                                                <form class="form-sample"
                                                                    action="<?php echo e(route('store.empolyee')); ?>"
                                                                    enctype="multipart/form-data" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <p class="card-description"> Personal info </p>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Name</label>
                                                                                <div class="col-sm-9">
                                                                                    <input type="text"
                                                                                        class="form-control"
                                                                                        name="name" required>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Email</label>
                                                                                <div class="col-sm-9">
                                                                                    <input type="email"
                                                                                        class="form-control"
                                                                                        name="email" required>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Gender</label>
                                                                                <div class="col-sm-9 ">
                                                                                    <select
                                                                                        class="form-control text-light"
                                                                                        name="gender" required>
                                                                                        <option value="male">Male
                                                                                        </option>
                                                                                        <option value="female">Female
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Number</label>
                                                                                <div class="col-sm-9">
                                                                                    <input type="number"
                                                                                        class="form-control text-light"
                                                                                        name="number" required>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Role</label>
                                                                                <div class="col-sm-9 ">
                                                                                    <select
                                                                                        class="form-control text-light"
                                                                                        name="role">
                                                                                        <option value="admin">Admin
                                                                                        </option>
                                                                                        <option value="empolyees">
                                                                                            Empolyee</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group row">
                                                                                <label
                                                                                    class="col-sm-3 col-form-label">Password</label>
                                                                                <div class="col-sm-9 ">
                                                                                    <input type="password"
                                                                                        class="form-control"
                                                                                        id="exampleInputPassword1"
                                                                                        placeholder="Password"
                                                                                        name="password">
                                                                                </div>
                                                                            </div>
                                                                        </div>


                                                                    </div>

                                                                    <button type="submit"
                                                                        class="btn btn-primary me-2">Create</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-dark">
                                        <thead>
                                            <tr>
                                                <th>Name </th>
                                                <th>Email</th>
                                                <th>Role</th>
                                                <th>Number</th>
                                                <th>Created at </th>
                                                <th>Acction</th>
                                            </tr>
                                        </thead>

                                        <tbody class="alldata">
                                            <?php $__currentLoopData = $empolyee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empolyees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                            <tr>
                                                <td> <?php echo e($empolyees->name); ?> </td>
                                                <td> <?php echo e($empolyees->email); ?></td>
                                                <td> <?php echo e($empolyees->role); ?></td>
                                                <td> <?php echo e($empolyees->number); ?></td>
                                                <td> <?php echo e($empolyees->created_at->format('d/m/Y')); ?>  <?php echo e($empolyees->created_at->format('g:i A')); ?></td>
                                                <td>
                                                    <div class="btn-group" role="group" aria-label="Basic example">
                                                        <a type="button" title="edit" class="btn btn-primary" href="<?php echo e(route('edit.empolyee',['id'=>$empolyees->id])); ?>">
                                                            <i class="mdi mdi-border-color"></i>
                                                        </a>

                                                        <form action="<?php echo e(route('delete.empolyee',['id'=>$empolyees->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-primary" title="delete forever">
                                                                <i class="mdi mdi-delete"></i>
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                        <tbody id="Content" class="searchdata"></tbody>


                                    </table>
                                    <div class="d-flex justify-content-center mt-3">
                                        <?php echo $empolyee->links('pagination::simple-bootstrap-4'); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script type="text/javascript">

       $('#search').on('keyup',function()
       {

        $value=$(this).val();

        if($value)
        {
            $('.alldata').hide();
            $('.searchdata').show();
        }else
        {
            $('.alldata').show();
            $('.searchdata').hide();
        }

        $.ajax({
                type:'get',
                url:'<?php echo e(URL::to('search')); ?>',
                data:{'search':$value},
                success:function(data)
                {
                    console.log(data);
                    $('#Content').html(data);
                }
            });

        });
    </script>

</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/empolyee/create.blade.php ENDPATH**/ ?>