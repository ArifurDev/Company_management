<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-lg-12 grid-margin stretch-card">
                            <div class="card">
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                              <div class="card-body">


                                <h4 class="card-title">Admin Daily Report</h4>
                                <form action="<?php echo e(route('admindailyraport.datasearch')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label
                                                    class="col-sm-3 col-form-label">From</label>
                                                <div class="col-sm-9 ">
                                                    <input type="date" class="form-control" id="" name="fromdate">

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label
                                                    class="col-sm-3 col-form-label">To</label>
                                                <div class="col-sm-9 ">
                                                    <input type="date" class="form-control" id=""name="today">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-2">
                                            <button class="btn btn-primary">Filter</button>
                                        </div>


                                    </div>
                                  </form>
                                <div class="d-flex justify-content-end align-items-center">



                                    
                                    <button type="button" class="btn btn-danger m-2" data-bs-toggle="modal" data-bs-target="#largeModal">
                                       Trash Bin
                                     </button>
                                </div>
                                 <!-- Large Modal -->
                                 <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content  bg-dark">
                                        <div class="modal-header ">
                                        <h5 class="modal-title" id="exampleModalLabel3">Trash Bin</h5>
                                        <button type="button"class="btn-close"data-bs-dismiss="modal"aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body m-1">
                                            <div class="table-responsive text-nowrap">
                                                <table class="table table-dark">

                                                <thead>
                                                    <tr>
                                                        <th> House Rent </th>
                                                        <th> Gard Bill </th>
                                                        <th> Electricity Bill </th>
                                                        <th> Sewerage Bill </th>
                                                        <th> Expanse </th>
                                                        <th> Personal </th>
                                                        <th> Loan </th>
                                                        <th> Total </th>
                                                        <th> Date </th>
                                                        <th> Action </th>
                                                    </tr>
                                                </thead>

                                                    <?php $__currentLoopData = $adminriports_onlyTrashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treshed_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td> <?php echo e($treshed_info->house_rent); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->gard_bill); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->electricity_bill); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->sewerage_bill); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->expanse); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->personal); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->loan); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->total); ?> tk</td>
                                                        <td> <?php echo e($treshed_info->created_at->format('d/m/Y')); ?></td>
                                                        <td>
                                                            <div class="btn-group" role="group" aria-label="Basic example">

                                                                <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.restor',['id'=>$treshed_info->id])); ?>" title="restore">
                                                                    <i class="mdi mdi-backup-restore"></i>
                                                                </a>
                                                                <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.delete',['id'=>$treshed_info->id])); ?>" title="delete forever">
                                                                    <i class="mdi mdi-delete-forever"></i>
                                                                </a>
                                                        </div></td>

                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>

                                        </div>

                                    </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                  <table class="table table-dark">
                                    <thead>
                                      <tr>
                                        <th> House Rent </th>
                                        <th> Gard Bill </th>
                                        <th> Electricity Bill </th>
                                        <th> Sewerage Bill </th>
                                        <th> Expanse </th>
                                        <th> Personal </th>
                                        <th> Loan </th>
                                        <th> Total </th>
                                        <th> Date </th>
                                        <th> Action </th>
                                      </tr>
                                    </thead>
                                    <tbody class="alldata">
                                        <?php $__currentLoopData = $adminriports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($info->house_rent); ?> tk</td>
                                            <td> <?php echo e($info->gard_bill); ?> tk</td>
                                            <td> <?php echo e($info->electricity_bill); ?> tk</td>
                                            <td> <?php echo e($info->sewerage_bill); ?> tk</td>
                                            <td> <?php echo e($info->expanse); ?> tk</td>
                                            <td> <?php echo e($info->personal); ?> tk</td>
                                            <td> <?php echo e($info->loan); ?> tk</td>
                                            <td> <?php echo e($info->total); ?> tk</td>
                                            <td> <?php echo e($info->created_at->format('d/m/Y')); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">

                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.edit',['id'=>$info->id])); ?>" title="edit">
                                                        <i class="mdi mdi-border-color"></i>
                                                    </a>
                                                    <a type="button" class="btn btn-primary" href="<?php echo e(route('admindailyraport.destroy',['id'=>$info->id])); ?>" title="delete tem">
                                                        <i class="mdi mdi-delete"></i>
                                                    </a>
                                            </div></td>

                                          </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                    </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/admin/report/show.blade.php ENDPATH**/ ?>