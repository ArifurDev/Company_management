<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                          <div class="card-body">
                            <h4 class="card-title">Admin Daily Report Edit</h4>
                            <div class="card-description ">

                                <p>Please fill the form correctly!</p>
                            </div>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>


                            <form class="forms-sample" action="<?php echo e(route('admindailyraport.update',['id'=>$adminriports->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                              <div class="form-group">
                                <label for="house_rent">House Rent</label>
                                <input type="number" class="form-control text-light" id="house_rent" placeholder="house_rent" name="house_rent" value="<?php echo e($adminriports->house_rent); ?>">
                              </div>
                              <div class="form-group">
                                <label for="gard_bill">Gard Bill</label>
                                <input type="number" class="form-control text-light" id="gard_bill" placeholder="gard_bill" name="gard_bill" value="<?php echo e($adminriports->gard_bill); ?>">
                              </div>
                              <div class="form-group">
                                <label for="electricity_bill">Electricity Bill</label>
                                <input type="number" class="form-control text-light" id="electricity_bill" placeholder="electricity_bill" name="electricity_bill" value="<?php echo e($adminriports->electricity_bill); ?>">
                              </div>
                              <div class="form-group">
                                <label for="sewerage_bill">Sewerage Bill</label>
                                <input type="number" class="form-control text-light" id="sewerage_bill" placeholder="sewerage_bill" name="sewerage_bill" value="<?php echo e($adminriports->sewerage_bill); ?>">
                              </div>
                              <div class="form-group">
                                <label for="expanse">Expanse</label>
                                <input type="number" class="form-control text-light" id="expanse" placeholder="expanse" name="expanse" value="<?php echo e($adminriports->expanse); ?>">
                              </div>
                              <div class="form-group">
                                <label for="personal">Personal</label>
                                <input type="number" class="form-control text-light" id="personal" placeholder="personal" name="personal" value="<?php echo e($adminriports->personal); ?>">
                              </div>
                              <div class="form-group">
                                <label for="Loan">loan</label>
                                <input type="number" class="form-control text-light" id="loan" placeholder="loan" name="loan" value="<?php echo e($adminriports->loan); ?>">
                              </div>
                              <button type="submit" class="btn btn-primary me-2">Update</button>
                            </form>
                          </div>
                        </div>
                      </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/admin/report/edit.blade.php ENDPATH**/ ?>