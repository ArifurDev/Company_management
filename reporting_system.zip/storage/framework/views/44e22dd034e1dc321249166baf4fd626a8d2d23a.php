
<?php
   $date = now();
  $to_day = $date->toFormattedDateString()
?>
<h1>today <?php echo e($to_day); ?></h1>
<p>আপনি কি আপনার কর্মচারীদের বেতন দিয়েছেন?
    যদি এখনো না দিয়ে থাকেন তো জরুরি ভিত্তিতে তাদের বেতন দিয়ে দিন</p>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/adminemails/adminemails.blade.php ENDPATH**/ ?>