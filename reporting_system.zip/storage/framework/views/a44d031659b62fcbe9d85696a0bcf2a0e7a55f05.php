<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                          <div class="card-body">
                            <h4 class="card-title">site info Edit</h4>
                            <div class="card-description ">

                                <p>Please fill the form correctly!</p>
                            </div>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li>
                                                <p class="text-light"><?php echo e($error); ?>

                                                </p>
                                            </li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            <form class="forms-sample" action="<?php echo e(route("adminwebreport.update",['id'=>$sitereports->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                              <div class="form-group">
                                <label for="site_name">Site Name</label>
                                <input type="text" class="form-control text-light" id="site_name" placeholder="site_name" name="site_name" value="<?php echo e($sitereports->site_name); ?>">
                              </div>
                              <div class="form-group">
                                <label for="url">URL</label>
                                <input type="url" class="form-control text-light" id="url" placeholder="url" name="url" value="<?php echo e($sitereports->url); ?>">
                              </div>
                              <div class="form-group">
                                <label for="user_name">User Name</label>
                                <input type="text" class="form-control text-light" id="user_name" placeholder="user_name" name="user_name" value="<?php echo e($sitereports->user_name); ?>">
                              </div>
                              <div class="form-group">
                                <label for="user_id">User Id</label>
                                <input type="number" class="form-control text-light" id="user_id" placeholder="user_id" name="user_id" value="<?php echo e($sitereports->user_id); ?>">
                              </div>
                              <div class="form-group">
                                <label for="password">Passeord</label>
                                <input type="text" class="form-control text-light" id="password" placeholder="password" name="password" value="<?php echo e($sitereports->password); ?>">
                              </div>
                              <div class="form-group">
                                <label for="verifi_code">Verification Code</label>
                                <input type="number" class="form-control text-light" id="verifi_code" placeholder="verifi_code" name="verifi_code" value="<?php echo e($sitereports->verifi_code); ?>">
                              </div>
                              <div class="form-group">
                                <label for="payment_date">Payment Date</label>
                                <input type="date" class="form-control text-light" id="payment_date" placeholder="payment_date" name="payment_date" value="<?php echo e($sitereports->payment_date); ?>">
                              </div>

                              <button type="submit" class="btn btn-primary me-2">Submit</button>
                            </form>
                          </div>
                        </div>
                      </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    



</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/admin/adminwebreportedit.blade.php ENDPATH**/ ?>