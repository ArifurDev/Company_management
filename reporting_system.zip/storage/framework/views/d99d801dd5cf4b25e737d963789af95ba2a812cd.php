<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="card" >

                            <div class="card-body">
                              <h5 class="card-title">Empolyee Report</h5>

                            </div>
                            <ul class="list-group  bg-dark">
                              <li class="list-group-item">Company:- <?php echo e($details->company); ?></li>
                              <li class="list-group-item">Empolyee Email:- <?php echo e($details->empolyee); ?></li>
                              <li class="list-group-item">Incoming:- <?php echo e($details->incoming); ?></li>
                              <li class="list-group-item">Outgoing:- <?php echo e($details->outgoing); ?></li>
                              <li class="list-group-item">Total:- <?php echo e($details->total); ?></li>
                              <li class="list-group-item">Cash:- <?php echo e($details->cash); ?></li>
                              <li class="list-group-item">Payment:- <?php echo e($details->card); ?></li>
                              <li class="list-group-item">Note:- <?php echo e($details->note); ?></li>
                              <li class="list-group-item">Submited_at:- <?php echo e($details->created_at); ?></li>
                              <li class="list-group-item">Updated_at:- <?php echo e($details->updated_at); ?></li>
                            </ul>
                            
                          </div>
                    </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/empolyeereport/details.blade.php ENDPATH**/ ?>