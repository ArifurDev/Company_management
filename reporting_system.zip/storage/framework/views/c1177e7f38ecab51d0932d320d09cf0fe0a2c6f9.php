<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('dashbord.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <?php echo $__env->make('dashbord.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('dashbord.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                          <div class="card-body">
                            <h4 class="card-title">Empolyee Daily Report Edit</h4>
                            <div class="card-description ">

                                <p>Please fill the form correctly!</p>
                            </div>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary" role="alert">
                                        <?php echo e(session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li>
                                                <p class="text-light"><?php echo e($error); ?>

                                                </p>
                                            </li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            <form class="forms-sample" action="<?php echo e(route("update.empolyeereport",['id'=>$empolyees->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                              <div class="form-group">
                                <label for="exampleInputCompany">Company</label>
                                <input type="text" class="form-control text-light" id="exampleInputCompany" placeholder="Company Name" name="company" value="<?php echo e($empolyees->company); ?>">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputIncoming">Incoming</label>
                                <input type="number" class="form-control text-light" id="exampleInputIncoming" placeholder="Incoming" name="incoming" value="<?php echo e($empolyees->incoming); ?>">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputIncoming">Outgoing</label>
                                <input type="number" class="form-control text-light" id="exampleInputIncoming" placeholder="Outgoing" name="outgoing" value="<?php echo e($empolyees->outgoing); ?>">
                              </div>
                              <div class="form-group">
                                <label for="exampleSelectGender">Card</label>
                                <select class="form-control text-light" id="exampleSelectGender" name="card">
                                  <option value="card"  <?php if($empolyees->card === 'card'): echo 'selected'; endif; ?>>card</option>
                                  <option value="none" <?php if($empolyees->card === 'none'): echo 'selected'; endif; ?>>None</option>
                                </select>
                              </div>


                              <div class="form-group">
                                <label for="exampleTextarea1">Note</label>
                                <textarea class="form-control text-light" id="exampleTextarea1" rows="4" name="note"><?php echo e($empolyees->note); ?></textarea>
                              </div>
                              <button type="submit" class="btn btn-primary me-2">Update</button>
                            </form>
                          </div>
                        </div>
                      </div>


                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('dashbord.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <?php echo $__env->make('dashbord.allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



</body>

</html>
<?php /**PATH H:\laragon\www\claint_project\reporting_system\resources\views/dashbord/empolyeereport/editempolyeereport.blade.php ENDPATH**/ ?>