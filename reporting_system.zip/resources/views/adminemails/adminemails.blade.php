
@php
   $date = now();
  $to_day = $date->toFormattedDateString()
@endphp
<h1>today {{ $to_day }}</h1>
<p>আপনি কি আপনার কর্মচারীদের বেতন দিয়েছেন?
    যদি এখনো না দিয়ে থাকেন তো জরুরি ভিত্তিতে তাদের বেতন দিয়ে দিন</p>
